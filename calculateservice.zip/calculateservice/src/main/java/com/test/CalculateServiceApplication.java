package com.test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;


@SpringBootApplication
public class CalculateServiceApplication {
	
	@Autowired
	Environment env;
	
	public static void main(String[] args) {
		SpringApplication.run(CalculateServiceApplication.class, args);
	}
	
	@PostConstruct
	public void init() {
		System.out.println("********** PostConstruct called !!!");
		System.out.println("********** Scenario Id is " + env.getProperty("scenarioid"));
		System.out.println("********** Scenario Name is " + env.getProperty("scenarioname"));
		System.out.println("********** Request Id is " + env.getProperty("requestid"));

		/*
        String connectStr = System.getenv("AZURE_STORAGE_CONNECTION_STRING");
        if (connectStr == null || connectStr.isEmpty()) connectStr = "DefaultEndpointsProtocol=https;AccountName=senchaonazure;AccountKey=BAotTp6k1sQRKNfiajFdeoAYTiE3hBvHyXQiroC4XmLWX3DNBKBgl5N2kyF7WBJ/W0DFIKmrXkcTyURKGK5Tag==;EndpointSuffix=core.windows.net";
        
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
		BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient("azurebatchtaskbinary");

		String requestid = "1234";
		String opsfileName = requestid + ".ops";
		BlobClient blobClient = containerClient.getBlobClient(opsfileName);
		blobClient.downloadToFile("C:/temp/1234.ops",true);
		System.out.println("OPS File downloaded successfully");
		
		System.out.println(" ************  Task Working dir is " + env.getProperty("AZURE_TASK_WORKING_DIR"));
		
		try {
			Path path = Paths.get("C:/temp/1234.ops");
			Charset charset = StandardCharsets.UTF_8;
			String content = new String(Files.readAllBytes(path), charset);
			System.out.println("Original content " + content);

			String originalPath = env.getProperty("AZURE_TASK_WORKING_DIR");
			System.out.println("******* Original ENV " + originalPath);
			String newPath = originalPath.replaceAll(Pattern.quote("\\"), "/");
			System.out.println("**** New ENV " + newPath);
			content = content.replaceAll("AZURE_TASK_WORKING_DIR", Matcher.quoteReplacement(newPath));
			System.out.println("New String " + content);

			//content = content.replaceAll("AZURE_JAVA_DIRECTORY", env.getProperty("AZURE_TASK_WORKING_DIR")); // "C:/Work/Java/OpenJDK11U-jdk"
			Files.write(path, content.getBytes(charset));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
	}
}