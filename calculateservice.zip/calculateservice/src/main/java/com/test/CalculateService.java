package com.test;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.microsoft.azure.PagedList;
import com.microsoft.azure.batch.BatchClient;
import com.microsoft.azure.batch.DetailLevel;
import com.microsoft.azure.batch.auth.BatchSharedKeyCredentials;
import com.microsoft.azure.batch.protocol.models.AutoUserSpecification;
import com.microsoft.azure.batch.protocol.models.BatchErrorException;
import com.microsoft.azure.batch.protocol.models.CloudPool;
import com.microsoft.azure.batch.protocol.models.CloudTask;
import com.microsoft.azure.batch.protocol.models.ElevationLevel;
import com.microsoft.azure.batch.protocol.models.EnvironmentSetting;
import com.microsoft.azure.batch.protocol.models.JobAddParameter;
import com.microsoft.azure.batch.protocol.models.JobConstraints;
import com.microsoft.azure.batch.protocol.models.NodeFile;
import com.microsoft.azure.batch.protocol.models.OutputFile;
import com.microsoft.azure.batch.protocol.models.PoolInformation;
import com.microsoft.azure.batch.protocol.models.ResourceFile;
import com.microsoft.azure.batch.protocol.models.TaskAddParameter;
import com.microsoft.azure.batch.protocol.models.TaskState;
import com.microsoft.azure.batch.protocol.models.UserIdentity;

@CrossOrigin
@Controller
public class CalculateService {

    public CalculateService() {
    }
    
    @GetMapping({ "/calculate" })
    @ResponseBody
    public String calculate(@RequestHeader HttpHeaders headers, 
    		@RequestParam(name = "requestid", required = false) String requestid,
    		@RequestParam(name = "calcid", required = true) String calcid,
    		@RequestParam(name = "calcname", required = true) String calcname,
    		@RequestParam(name = "calcmethodurl", required = true) String calcmethodurl) {

        if (requestid == null || requestid.equalsIgnoreCase("")) {
        	requestid = String.valueOf(System.currentTimeMillis());
        	System.out.println("Calculate API called without any request Id, so generated " + requestid);        	
        }
        else {
        	System.out.println("Calculate API called with request Id " + requestid);
        }

        // Download the Calculation method from given URL
        String fileName = requestid + "-calcparam.txt";
        try {
        	
			URL url = new URL(calcmethodurl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer content = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
			    content.append(inputLine);
			}
			System.out.println("Response: " + content.toString());
			
			// Write content to the file
			FileWriter writer = new FileWriter(fileName, true);
			writer.write(content.toString());
			writer.close();
        }
        catch (Exception ex) {
        	System.out.println("Error while downloading Calc Method " + ex.getMessage());
        	return "Unable to download calculation method from the given URL " + calcmethodurl;
        }
		
        String connectStr = System.getenv("AZURE_STORAGE_CONNECTION_STRING");
        if (connectStr == null || connectStr.isEmpty()) connectStr = "DefaultEndpointsProtocol=https;AccountName=senchaonazure;AccountKey=BAotTp6k1sQRKNfiajFdeoAYTiE3hBvHyXQiroC4XmLWX3DNBKBgl5N2kyF7WBJ/W0DFIKmrXkcTyURKGK5Tag==;EndpointSuffix=core.windows.net";
        
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
		BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient("azurebatchtaskbinary");
		if(!containerClient.exists()) containerClient = createContainer(blobServiceClient, "azurebatchtaskbinary");
		
		uploadBlob(containerClient, fileName);
		
        String azureBatchBaseURL = System.getenv("Batch_Service_Base_URL");
        System.out.println("Azure Batch Base URL is " + azureBatchBaseURL);
        if (azureBatchBaseURL == null || azureBatchBaseURL.isEmpty()) azureBatchBaseURL = "https://fintechbatch.eastus.batch.azure.com";
        
        String azureBatchAccountName = System.getenv("Batch_Service_Account_Name");
        if (azureBatchAccountName == null || azureBatchAccountName.isEmpty()) azureBatchAccountName = "fintechbatch";
        
        String azureBatchAccessKey = System.getenv("Batch_Service_Access_Key");
        if (azureBatchAccessKey == null || azureBatchAccessKey.isEmpty()) azureBatchAccessKey = "FKjzNV2EHTeF6NC0pl/52ANJf5Qkr2WcS+/W0HgPaSA70UCK+0V+gV9Q9z31ir/uMxz4MxnyLflPYNHJLqSuSg==";
        
        String azureBatchPoolName = System.getenv("Batch_Service_Pool_Name");
        if (azureBatchPoolName == null || azureBatchPoolName.isEmpty()) azureBatchPoolName = "windowspool";
        //if (azureBatchPoolName == null || azureBatchPoolName.isEmpty()) azureBatchPoolName = "testpool";
        
        System.out.println("Access Key " + azureBatchAccessKey);
        
        // Create Azure Batch Client
        BatchClient client = BatchClient.open(new BatchSharedKeyCredentials(azureBatchBaseURL, azureBatchAccountName, azureBatchAccessKey));
        System.out.println("Successfully created Batch Client");
        
        try {
        	
        	// Get reference to appropriate pool
			CloudPool pool = client.poolOperations().getPool(azureBatchPoolName);
			System.out.println("Successfully looked up Batch Service Pool " + azureBatchPoolName);
			
			// Create Job
			client.jobOperations().createJob(requestid + "-Job", new PoolInformation().withPoolId(pool.id()));
			System.out.println("Successfully created Job " + requestid + "-Job");
			
			// Create task
			List<ResourceFile> files = new ArrayList<>();
			String calculator_jar_file_URL = System.getenv("Calculator_JAR_file_URL");
			if (calculator_jar_file_URL == null || calculator_jar_file_URL.isEmpty()) calculator_jar_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/azurebatchtask.jar";
			
			String calculator_jar_file_local_path = System.getenv("Calculator_JAR_file_Local_Path");
			if (calculator_jar_file_local_path == null || calculator_jar_file_local_path.isEmpty()) calculator_jar_file_local_path = "azurebatchtask.jar"; 
			
			//String task_command = System.getenv("Batch_Task_Command");
			//task_command = "/bin/bash -c 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar azurebatchtask.jar'";
			
			/* Uncomment the following code if we want to run the task on a Linux OS 
			StringBuffer buffer = new StringBuffer();
			buffer.append("/bin/bash -c ");
			buffer.append("\'");
			buffer.append("export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar ");
			buffer.append(calculator_jar_file_local_path);
			buffer.append(" ");
			buffer.append(requestid);
			buffer.append("\'");
			String task_command = buffer.toString();
			if (task_command == null || task_command.isEmpty()) {
				task_command = "/bin/bash -c 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar azurebatchtask.jar'";
	        }
			*/
			
			StringBuffer buffer = new StringBuffer();
			buffer.append("cmd /c ");
			buffer.append("D:\\ProgramData\\Oracle\\Java\\javapath\\java.exe -jar ");
			buffer.append(calculator_jar_file_local_path);
			buffer.append(" ");
			buffer.append(requestid);
			String task_command = buffer.toString();
			if (task_command == null || task_command.isEmpty()) {
				task_command = "/bin/bash -c 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar azurebatchtask.jar'";
	        }

	        files.add(new ResourceFile().withBlobSource(calculator_jar_file_URL).withFilePath(calculator_jar_file_local_path));
	        
	        /* Uncomment following code if the Task is running on Linux node
			String calculator_dll_file_URL = System.getenv("Calculator_DLL_file_URL");
			if (calculator_dll_file_URL == null || calculator_dll_file_URL.isEmpty()) calculator_dll_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/libnativecalculator.so";
			
			String calculator_dll_file_local_path = System.getenv("Calculator_DLL_file_Local_Path");
			if (calculator_dll_file_local_path == null || calculator_dll_file_local_path.isEmpty())	calculator_dll_file_local_path = "libnativecalculator.so"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_dll_file_URL).withFilePath(calculator_dll_file_local_path));
			*/
	        
			String calculator_windows_dll_file_URL = System.getenv("Calculator_Windows_DLL_file_URL");
			if (calculator_windows_dll_file_URL == null || calculator_windows_dll_file_URL.isEmpty()) calculator_windows_dll_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/CALCULATE.DLL";
			
			String calculator_windows_dll_file_local_path = System.getenv("Calculator_Windows_DLL_file_Local_Path");
			if (calculator_windows_dll_file_local_path == null || calculator_windows_dll_file_local_path.isEmpty())	calculator_windows_dll_file_local_path = "CALCULATE.DLL"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_windows_dll_file_URL).withFilePath(calculator_windows_dll_file_local_path));

			String calculator_windows_header_file_URL = System.getenv("Calculator_Windows_HEADER_file_URL");
			if (calculator_windows_header_file_URL == null || calculator_windows_header_file_URL.isEmpty()) calculator_windows_header_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/Calculate.h";
			
			String calculator_windows_header_file_local_path = System.getenv("Calculator_Windows_HEADER_file_Local_Path");
			if (calculator_windows_header_file_local_path == null || calculator_windows_header_file_local_path.isEmpty()) calculator_windows_header_file_local_path = "Calculate.h"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_windows_header_file_URL).withFilePath(calculator_windows_header_file_local_path));

			String calculator_windows_lib_file_URL = System.getenv("Calculator_Windows_LIB_file_URL");
			if (calculator_windows_lib_file_URL == null || calculator_windows_lib_file_URL.isEmpty()) calculator_windows_lib_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/CALCULATE.lib";
			
			String calculator_windows_lib_file_local_path = System.getenv("Calculator_Windows_LIB_file_Local_Path");
			if (calculator_windows_lib_file_local_path == null || calculator_windows_lib_file_local_path.isEmpty()) calculator_windows_lib_file_local_path = "CALCULATE.lib"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_windows_lib_file_URL).withFilePath(calculator_windows_lib_file_local_path));
			
	        TaskAddParameter taskToAdd = new TaskAddParameter().withId(requestid + "-Task").withCommandLine(task_command).withResourceFiles(files).withUserIdentity(new UserIdentity().withAutoUser(new AutoUserSpecification().withElevationLevel(ElevationLevel.ADMIN)));			
			client.taskOperations().createTask(requestid + "-Job", taskToAdd);
			System.out.println("Successfully created Task " + requestid + "-Task");
			
		} catch (BatchErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        return "Success !! We have uploaded the content of " + calcmethodurl + " on Azure Blob Storage and will be used during Calculation. You can check the status of Calculate Operation using RequestId " + requestid;
    }    

    private void downloadBlob(BlobContainerClient containerClient, String fileName) {
		// TODO Auto-generated method stub
    	BlobClient blobClient = containerClient.getBlobClient(fileName);
		blobClient.downloadToFile(fileName, true);
		System.out.println("File downloaded successfully");
	}

	private void uploadBlob(BlobContainerClient containerClient, String fileName) {
		// TODO Auto-generated method stub
		BlobClient blobClient = containerClient.getBlobClient(fileName);
		blobClient.uploadFromFile(fileName, true);
		System.out.println("File uploaded successfully");
	}

	private BlobContainerClient createContainer(BlobServiceClient blobServiceClient, String containerName) {
		// TODO Auto-generated method stub
		return blobServiceClient.createBlobContainer(containerName);
	}

	@GetMapping({ "/cancel" })
    @ResponseBody
    public String cancelCalculation(@RequestHeader HttpHeaders headers, 
    		@RequestParam(name = "requestid", required = true) String requestid) {

        System.out.println("Cancel API called with request Id " + requestid);

        String azureBatchBaseURL = System.getenv("Batch_Service_Base_URL");
        if (azureBatchBaseURL == null || azureBatchBaseURL.equalsIgnoreCase("")) azureBatchBaseURL = "https://fintechbatch.eastus.batch.azure.com";
        String azureBatchAccountName = System.getenv("Batch_Service_Account_Name");
        if (azureBatchAccountName == null || azureBatchAccountName.equalsIgnoreCase("")) azureBatchAccountName = "fintechbatch";
        String azureBatchAccessKey = System.getenv("Batch_Service_Access_Key");
        if (azureBatchAccessKey == null || azureBatchAccessKey.equalsIgnoreCase("")) azureBatchAccessKey = "FKjzNV2EHTeF6NC0pl/52ANJf5Qkr2WcS+/W0HgPaSA70UCK+0V+gV9Q9z31ir/uMxz4MxnyLflPYNHJLqSuSg==";
        
        System.out.println("Access Key " + azureBatchAccessKey);
        
        // Create Azure Batch Client
        BatchClient client = BatchClient.open(new BatchSharedKeyCredentials(azureBatchBaseURL, azureBatchAccountName, azureBatchAccessKey));
        System.out.println("Successfully created Batch Client");
        
        try {
        	
			// Lookup Task
			CloudTask task = client.taskOperations().getTask(requestid+"-Job", requestid+"-Task");
			if (task != null) {
				System.out.println("Successfully looked up Calculate Task for cancellation");
                if (task.state() == TaskState.COMPLETED) {
                	client.jobOperations().deleteJob(requestid+"-Job");
                	return "Oops !! The Calculate operation has already completed, so can't cancel it anymore for " + requestid + " !!";
                }
                else {
                	client.taskOperations().terminateTask(requestid+"-Job", requestid+"-Task");
                	client.jobOperations().deleteJob(requestid+"-Job");
                }
                
			}
			else {
				System.out.println("Task to be deleted does not exists !!");
				return "Cancel Task does not exists for " + requestid + " !!";
            }
		} catch (BatchErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return "Success !! Cancel operation is successful for RequestId " + requestid;
    }

    @GetMapping({ "/solve" })
    @ResponseBody
    public String solve(@RequestHeader HttpHeaders headers, 
    		@RequestParam(name = "requestid", required = false) String requestid) {

        if (requestid == null || requestid.equalsIgnoreCase("")) {
        	requestid = String.valueOf(System.currentTimeMillis());
        	System.out.println("Solve API called without any request Id, so generated " + requestid);        	
        }
        else {
        	System.out.println("Solve API called with request Id " + requestid);
        }
        
        String jobId = String.valueOf(System.currentTimeMillis());

        String connectStr = System.getenv("AZURE_STORAGE_CONNECTION_STRING");
        if (connectStr == null || connectStr.isEmpty()) {
        	connectStr = "DefaultEndpointsProtocol=https;AccountName=tmodsolvestorageaccount;AccountKey=Hbjt98qtyYWiE6Cm47qvV/EX6PCjw9ZzC0TSZGLq0NxDXwVrLKmSIb00qE+CTGg+wpZ2YZtnjaCZxxQlg86ylg==;EndpointSuffix=core.windows.net";
        }
        
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
		
        String azureBatchBaseURL = System.getenv("Batch_Service_Base_URL");
        System.out.println("Azure Batch Base URL is " + azureBatchBaseURL);
        if (azureBatchBaseURL == null || azureBatchBaseURL.isEmpty()) {
        	azureBatchBaseURL = "https://tmodsolvebatch.eastus2.batch.azure.com";
        }
        
        String azureBatchAccountName = System.getenv("Batch_Service_Account_Name");
        if (azureBatchAccountName == null || azureBatchAccountName.isEmpty()) {
        	azureBatchAccountName = "tmodsolvebatch";
        }
        
        String azureBatchAccessKey = System.getenv("Batch_Service_Access_Key");
        if (azureBatchAccessKey == null || azureBatchAccessKey.isEmpty()) {
        	azureBatchAccessKey = "3PLG0kiSnNOC7BRTgMN6TsJJF1XfgvLrvm3yF9svn7pF/xwKjupdK2ofRpomuSTbApYZVp3hqVoDQjC4BAVbIQ==";
        }
        
        String azureBatchPoolName = System.getenv("Batch_Service_Pool_Name");
        if (azureBatchPoolName == null || azureBatchPoolName.isEmpty()) {
        	azureBatchPoolName = "solvewindowspool";
        }
        //if (azureBatchPoolName == null || azureBatchPoolName.isEmpty()) azureBatchPoolName = "testpool";
        
        System.out.println("Access Key " + azureBatchAccessKey);
        
        // Create Azure Batch Client
        BatchClient client = BatchClient.open(new BatchSharedKeyCredentials(azureBatchBaseURL, azureBatchAccountName, azureBatchAccessKey));
        System.out.println("Successfully created Batch Client");
        
        try {
        	
        	// Get reference to appropriate pool
			CloudPool pool = client.poolOperations().getPool(azureBatchPoolName);
			System.out.println("Successfully looked up Batch Service Pool " + azureBatchPoolName);
			
			// Create Job
			client.jobOperations().createJob(jobId + "-Job", new PoolInformation().withPoolId(pool.id()));
			System.out.println("Successfully created Job " + jobId + "-Job");
			
			// Create task
			/*
			List<ResourceFile> files = new ArrayList<>();
			String calculator_jar_file_URL = System.getenv("Calculator_JAR_file_URL");
			if (calculator_jar_file_URL == null || calculator_jar_file_URL.isEmpty()) calculator_jar_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/azurebatchtask.jar";
			
			String calculator_jar_file_local_path = System.getenv("Calculator_JAR_file_Local_Path");
			if (calculator_jar_file_local_path == null || calculator_jar_file_local_path.isEmpty()) calculator_jar_file_local_path = "azurebatchtask.jar"; 
			
			//String task_command = System.getenv("Batch_Task_Command");
			//task_command = "/bin/bash -c 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar azurebatchtask.jar'";
			*/
			/* Uncomment the following code if we want to run the task on a Linux OS 
			StringBuffer buffer = new StringBuffer();
			buffer.append("/bin/bash -c ");
			buffer.append("\'");
			buffer.append("export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar ");
			buffer.append(calculator_jar_file_local_path);
			buffer.append(" ");
			buffer.append(requestid);
			buffer.append("\'");
			String task_command = buffer.toString();
			if (task_command == null || task_command.isEmpty()) {
				task_command = "/bin/bash -c 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar azurebatchtask.jar'";
	        }
			*/
			StringBuffer buffer = new StringBuffer();
			buffer.append("cmd /c ");
			buffer.append("%AZ_BATCH_APP_PACKAGE_OpenJDK11%/OpenJDK11U-jdk/bin/java ");
			buffer.append("-Djava.library.path=%AZ_BATCH_APP_PACKAGE_SolveTask%/DLLs ");
			buffer.append("-jar %AZ_BATCH_APP_PACKAGE_SolveTask%/tmod-solver-2020.1.0.0-exec.jar ");
			buffer.append("--scenarioid=60125a2b843e4d5d484bce8a --scenarioname=SC-2 --userid=abc --requestid=");
			buffer.append(requestid);
			String task_command = buffer.toString();
			/*
			if (task_command == null || task_command.isEmpty()) {
				task_command = "/bin/bash -c 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar azurebatchtask.jar'";
	        }
	        */
			/*
			StringBuffer buffer = new StringBuffer();
			buffer.append("cmd /c ");
			buffer.append("D:\\ProgramData\\Oracle\\Java\\javapath\\java.exe -jar ");
			buffer.append(calculator_jar_file_local_path);
			buffer.append(" ");
			buffer.append(requestid);
			String task_command = buffer.toString();
			if (task_command == null || task_command.isEmpty()) {
				task_command = "/bin/bash -c 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.;java -jar azurebatchtask.jar'";
	        }
			*/
	        //files.add(new ResourceFile().withBlobSource(calculator_jar_file_URL).withFilePath(calculator_jar_file_local_path));
	        
	        List<EnvironmentSetting> environmentSettings = new ArrayList<EnvironmentSetting>();
	        EnvironmentSetting path = new EnvironmentSetting().withName("PATH").withValue("%AZ_BATCH_APP_PACKAGE_SolveTask%/DLLs;%PATH%");
	        EnvironmentSetting azureConnectionString = new EnvironmentSetting().withName("AZURE_STORAGE_CONNECTION_STRING").withValue("DefaultEndpointsProtocol=https;AccountName=tmodsolvestorageaccount;AccountKey=Hbjt98qtyYWiE6Cm47qvV/EX6PCjw9ZzC0TSZGLq0NxDXwVrLKmSIb00qE+CTGg+wpZ2YZtnjaCZxxQlg86ylg==;EndpointSuffix=core.windows.net");
	        EnvironmentSetting openjdkPath = new EnvironmentSetting().withName("AZURE_OPENJDK_DIRECTORY").withValue("%AZ_BATCH_APP_PACKAGE_OpenJDK11%/OpenJDK11U-jdk");
	        
	        environmentSettings.add(path);
	        environmentSettings.add(azureConnectionString);
	        environmentSettings.add(openjdkPath);
			/* Uncomment following code if the Task is running on Linux node
			String calculator_dll_file_URL = System.getenv("Calculator_DLL_file_URL");
			if (calculator_dll_file_URL == null || calculator_dll_file_URL.isEmpty()) calculator_dll_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/libnativecalculator.so";
			
			String calculator_dll_file_local_path = System.getenv("Calculator_DLL_file_Local_Path");
			if (calculator_dll_file_local_path == null || calculator_dll_file_local_path.isEmpty())	calculator_dll_file_local_path = "libnativecalculator.so"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_dll_file_URL).withFilePath(calculator_dll_file_local_path));
			*/
	        /*
			String calculator_windows_dll_file_URL = System.getenv("Calculator_Windows_DLL_file_URL");
			if (calculator_windows_dll_file_URL == null || calculator_windows_dll_file_URL.isEmpty()) calculator_windows_dll_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/CALCULATE.DLL";
			
			String calculator_windows_dll_file_local_path = System.getenv("Calculator_Windows_DLL_file_Local_Path");
			if (calculator_windows_dll_file_local_path == null || calculator_windows_dll_file_local_path.isEmpty())	calculator_windows_dll_file_local_path = "CALCULATE.DLL"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_windows_dll_file_URL).withFilePath(calculator_windows_dll_file_local_path));
		
			String calculator_windows_header_file_URL = System.getenv("Calculator_Windows_HEADER_file_URL");
			if (calculator_windows_header_file_URL == null || calculator_windows_header_file_URL.isEmpty()) calculator_windows_header_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/Calculate.h";
			
			String calculator_windows_header_file_local_path = System.getenv("Calculator_Windows_HEADER_file_Local_Path");
			if (calculator_windows_header_file_local_path == null || calculator_windows_header_file_local_path.isEmpty()) calculator_windows_header_file_local_path = "Calculate.h"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_windows_header_file_URL).withFilePath(calculator_windows_header_file_local_path));

			String calculator_windows_lib_file_URL = System.getenv("Calculator_Windows_LIB_file_URL");
			if (calculator_windows_lib_file_URL == null || calculator_windows_lib_file_URL.isEmpty()) calculator_windows_lib_file_URL = "https://senchaonazure.blob.core.windows.net/azurebatchtaskbinary/CALCULATE.lib";
			
			String calculator_windows_lib_file_local_path = System.getenv("Calculator_Windows_LIB_file_Local_Path");
			if (calculator_windows_lib_file_local_path == null || calculator_windows_lib_file_local_path.isEmpty()) calculator_windows_lib_file_local_path = "CALCULATE.lib"; 
	        
			files.add(new ResourceFile().withBlobSource(calculator_windows_lib_file_URL).withFilePath(calculator_windows_lib_file_local_path));
			*/
	        //TaskAddParameter taskToAdd = new TaskAddParameter().withId(requestid + "-Task").withCommandLine(task_command).withResourceFiles(files).withUserIdentity(new UserIdentity().withAutoUser(new AutoUserSpecification().withElevationLevel(ElevationLevel.ADMIN)));
			TaskAddParameter taskToAdd = new TaskAddParameter().withId(jobId + "-Task").withCommandLine(task_command).withEnvironmentSettings(environmentSettings ).withUserIdentity(new UserIdentity().withAutoUser(new AutoUserSpecification().withElevationLevel(ElevationLevel.ADMIN)));
			client.taskOperations().createTask(jobId + "-Job", taskToAdd);
			System.out.println("Successfully created Task " + jobId + "-Task");
			
		} catch (BatchErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        return "Success !! We have created a Solve Job with Job Id " + jobId + "-Job" + " on Azure Batch";
    }    
	
    @GetMapping({ "/status" })
    @ResponseBody
    public String getStatus(@RequestHeader HttpHeaders headers, 
    		@RequestParam(name = "requestid", required = true) String requestid) {

        System.out.println("Status API called with request Id " + requestid);

        String azureBatchBaseURL = System.getenv("Batch_Service_Base_URL");
        if (azureBatchBaseURL == null || azureBatchBaseURL.equalsIgnoreCase("")) azureBatchBaseURL = "https://fintechbatch.eastus.batch.azure.com";
        //azureBatchBaseURL = "https://fintechbatch.eastus.batch.azure.com";//Temp code
        
        String azureBatchAccountName = System.getenv("Batch_Service_Account_Name");
        if (azureBatchAccountName == null || azureBatchAccountName.equalsIgnoreCase("")) azureBatchAccountName = "fintechbatch";
        //azureBatchAccountName = "fintechbatch";//Temp code
        
        String azureBatchAccessKey = System.getenv("Batch_Service_Access_Key");
        if (azureBatchAccessKey == null || azureBatchAccessKey.equalsIgnoreCase("")) azureBatchAccessKey = "FKjzNV2EHTeF6NC0pl/52ANJf5Qkr2WcS+/W0HgPaSA70UCK+0V+gV9Q9z31ir/uMxz4MxnyLflPYNHJLqSuSg==";
        //azureBatchAccessKey = "FKjzNV2EHTeF6NC0pl/52ANJf5Qkr2WcS+/W0HgPaSA70UCK+0V+gV9Q9z31ir/uMxz4MxnyLflPYNHJLqSuSg==";//Temp code
        System.out.println("Access Key " + azureBatchAccessKey);
        
        // Create Azure Batch Client
        BatchClient client = BatchClient.open(new BatchSharedKeyCredentials(azureBatchBaseURL, azureBatchAccountName, azureBatchAccessKey));
        System.out.println("Successfully created Batch Client");
        
        try {

        	// Lookup Task
			CloudTask task = client.taskOperations().getTask(requestid+"-Job", requestid+"-Task");
			
			if (task != null) {
				System.out.println("Successfully looked up Calculate Task for status retrieval");
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				if (task.nodeInfo() != null) {
					System.out.println("Pool Id " + task.nodeInfo().poolId() + " with Node Id " + task.nodeInfo().nodeId());
					PagedList<NodeFile> filesOnNode = client.fileOperations().listFilesFromComputeNode(task.nodeInfo().poolId(), task.nodeInfo().nodeId(), true, null , null);
					if (filesOnNode != null) {
						Iterator<NodeFile> iter = filesOnNode.iterator();
						while (iter.hasNext()) {
							NodeFile file = iter.next();
							System.out.println("File name is " + file.name() + " with URL " + file.url());
						}
					}
					
					client.fileOperations().getFileFromComputeNode(task.nodeInfo().poolId(), task.nodeInfo().nodeId(), task.nodeInfo().taskRootDirectory() + "/wd/result.txt", stream);
					return stream.toString("UTF-8");
				}
				else {
					return "Current state of Task is " + task.state().name() + ", so please wait while the Task starts running !!";
				}
			}
			else {
				System.out.println("Task does not exists !!");
				return "Task does not exists for " + requestid + " !!";
            }
		} catch (BatchErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return "Oops !! Could not find status for " + requestid;
    }    
}